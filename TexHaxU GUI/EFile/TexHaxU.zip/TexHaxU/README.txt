Made for texture hacking.

It's a combination of IEA's stuff with a few scripts I made to automate the process even more.
Double click extract.bat which asks you for the BFRES name, and it'll auto extract textures. 
then run convertGTX.bat to convert them all to DDS (you should only use the lossless versions).
You can open the DDS files in paint.net and save as PNG to edit in Photoshop, then convert the new PNG back to DDS. 
Then using hax.py (syntax auto prints every time) to list all texture positions in the bfres, and then use it to splice in the dds texture after it auto converts to the right format. 
You'll need to make sure mipmap sizes match, otherwise weird things will probably happen. 
Thankfully TexConv2 handles mipmaps so you just need to guess the right minmip number (for Nintendo Land it's usually 1 for a 1x1 mipmap). 
You might also need to adjust the delay loops in the python script if texconv2 is super slow.